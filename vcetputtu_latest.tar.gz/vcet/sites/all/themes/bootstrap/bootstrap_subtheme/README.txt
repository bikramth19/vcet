To help consolidate and remove possible future inconsistencies, the
documentation for this sub-theme starter kit has been moved to:
http://drupal.org/node/1978010.
